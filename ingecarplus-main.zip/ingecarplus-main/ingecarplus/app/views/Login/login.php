<link rel="stylesheet" type= "text/css" href="../css/css_login.css">
<div class="wrapper">
    <form class="login">
      <p class="title">Inicio de sesión</p>
      <input type="text" placeholder="Username" autofocus/>
      <i class="fa fa-user"></i>
      <input type="password" placeholder="Password" />
      <i class="fa fa-key"></i>
      <a href="../Register/registro.php">¿No tienes cuenta aun?</a>
      <button>
        <i class="spinner"></i>
        <span class="state">Ingresar</span>
      </button>
    </form>
    <footer><a target="blank" href="../Home/homepage.php">Ingecarplus.com</a></footer>
    </p>
  </div>