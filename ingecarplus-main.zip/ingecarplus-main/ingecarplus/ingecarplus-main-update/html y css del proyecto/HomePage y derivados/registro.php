<link rel="stylesheet" type= "text/css" href="css/css_login.css">
<div class="wrapper">
    <form class="login">
      <p class="title">Registro</p>
      <input type="text" placeholder="Username" autofocus/>
      <i class="fa fa-user"></i>
      <input type="password" placeholder="Password" />
      <input type="password" placeholder="Confirm password" />
      <i class="fa fa-key"></i>
      <a href="login.php">¿Ya tienes cuenta?</a>
      <button>
        <i class="spinner"></i>
        <span class="state">Registrarte</span>
      </button>
    </form>
    <footer><a target="blank" href="index.html">Ingecarplus.com</a></footer>
    </p>
  </div>