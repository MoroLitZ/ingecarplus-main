<?php
require_once(PATH_MODELS .'/register/RegisterModel.php');

class ConsultasController extends Controller {
    public function exec(){
        
    }
}