<?php
require_once(PATH_MODELS .'consultas/ConsultasModel.php');

class ConsultasController extends Controller {
    public function exec(){
        
    }
}