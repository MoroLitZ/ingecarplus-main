<?php
require_once(PATH_MODELS .'/agendar_cita/Agendar_citaModel.php');

class ConsultasController extends Controller {
    public function exec(){
        
    }
}