<?php

use ConsultasController as GlobalConsultasController;

require_once(PATH_MODELS .'consultas/ConsultasModel.php');

class ConsultasController extends Controller {
    public function exec(){
        echo "kjuhgjkgkghik";
        $this->render(__CLASS__);
    }
}